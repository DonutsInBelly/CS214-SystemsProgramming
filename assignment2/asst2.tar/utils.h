#include <stdio.h>
#include <stdlib.h>
#include "lols.h"

#ifndef UTILS_H
#define UTILS_H

void *compress(void *);
void writeToFile(char *, Segment);

#endif
