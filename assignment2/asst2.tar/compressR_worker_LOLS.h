#include <stdio.h>
#include <stdlib.h>
#include "lols.h"
#include "utils.h"

#ifndef compressR_worker_LOLS_H
#define compressR_worker_LOLS_H

void worker(FileData *);

#endif
